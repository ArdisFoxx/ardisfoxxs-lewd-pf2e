Change log: 

* 1.0.0 - Initial Release
* 1.1.0 - Added Actors. Updated icons and text for all items. Added new conditions, kinks and items. Added support for bondage, ovipositor and pregnancy options.
