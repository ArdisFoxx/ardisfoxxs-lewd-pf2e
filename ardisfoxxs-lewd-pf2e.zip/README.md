# ardisfoxxs-lewd-pf2e
Items, Spells, Effects, Conditions and Macros to support adding NSFW/Lewd rules and content to Pathfinder 2e.
