# ardisfoxxs-lewd-pf2e
Add NSFW rules, items, spells, effects and conditions to your lewd roleplay PF2e campaign! Purchase of this module allows access to all future AFLP update releases.

Content Warning: This module is R13+. The author highly  recommends outlining this content with your group in Session 0 and agreeing as a group on how much NSFW content to include. A Session 0 Content Guide is included as part of this module.

Purchase here: https://www.patreon.com/ardisfoxxart/shop/ardisfoxxs-lewd-pf2e-1272244
